# 🚀 Boom Content Creator Agent  
An AI-powered content agent for Boom Token marketing and analytics  

## 📌 Features  
- 🔹 **Real-time Price Tracking** – Fetches BOOM token price from PancakeSwap via DexScreener.  
- 🔹 **Transaction Monitoring** – Tracks large BOOM token transactions on BSC.  
- 🔹 **Holder Growth Insights** – Analyzes new token holders using BscScan.  
- 🔹 **Twitter Bot Integration** – Auto-posts Boom Token price updates.  

## 📌 Installation & Setup  
1️⃣ **Clone the Repository**  
```bash  
git clone https://github.com/YOUR_GITHUB_USERNAME/boom-content-agent.git  
cd boom-content-agent  
```  

2️⃣ **Install Dependencies**  
```bash  
pip install requests tweepy  
```  

3️⃣ **Configure API Keys**  
Rename `.env.example` to `.env` and add your keys.  

4️⃣ **Run the Bot**  
```bash  
python content_creator.py  
```  

## 📌 Project Structure  
```
boom-content-agent/  
│── content_creator.py   # Main agent script  
│── config.yaml          # Configuration file  
│── .env.example         # API keys (ignored in Git)  
│── README.md            # Project documentation  
│── requirements.txt     # Dependencies  
```
