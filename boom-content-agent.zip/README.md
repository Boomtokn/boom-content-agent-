# 🚀 Boom Content Creator Agent

An AI-powered content agent for Boom Token marketing and analytics.

## 📌 Features
- 🔹 **Real-time Price Tracking** – Fetches BOOM token price from PancakeSwap via DexScreener.
- 🔹 **Transaction Monitoring** – Tracks large BOOM token transactions on BSC.
- 🔹 **Holder Growth Insights** – Analyzes new token holders using BscScan.
- 🔹 **Twitter Bot Integration** – Auto-posts Boom Token price updates.

## 📌 Installation & Setup

### 1. Clone the Repository
```bash
git clone https://github.com/YOUR_GITHUB_USERNAME/boom-content-agent.git
cd boom-content-agent
```

### 2. Install Dependencies
```bash
pip install requests tweepy python-dotenv
```

### 3. Create and Configure the Environment Variables File
Create a file named **.env** in the root directory of the project (the same folder that contains this README) and paste in the following content:

```env
# Rename this file to .env and add your API keys
AGENTOPS_API_KEY="e8af59e5-a854-486b-b5de-63b7005b546b"
BSC_API_KEY="761U63ER4DQEMBYX9G5DSUKV37HYCZFKKY"
TWITTER_API_KEY="agSPH2JZX3v1xZJ9d5TkxbmCz"
TWITTER_API_SECRET="sF6OnIuEGBg9hMdVlAejWXS6DZ3F9BQ7pesvAbeYUbxtR868uO"
TWITTER_ACCESS_TOKEN="1547480536943398912-VxxUah6ncJufOyx7k5wnfhFiabHqIE"
TWITTER_ACCESS_SECRET="iBi9GmtzMlbs7ZHuSm5NRKmv7yfaW1vzMDrwrXKVyQVWD"
```

**Security Note:** If you're pushing your project to a public repository, add **.env** to your **.gitignore** file to avoid exposing your sensitive API keys.

### 4. Run the Bot
```bash
python content_creator.py
```

## 📌 Project Structure
```
boom-content-agent/
│── content_creator.py   # Main agent script (to be implemented)
│── .env                 # Environment variables file (contains API keys)
│── README.md            # Project documentation
│── requirements.txt     # Dependencies list (to be added)
```

## 📌 Contributing
Feel free to submit pull requests and improve the project! 🚀
