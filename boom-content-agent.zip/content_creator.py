import requests  
import tweepy  
import os  

# Load API keys from environment variables  
BSC_API_KEY = os.getenv("BSC_API_KEY")  
TWITTER_API_KEY = os.getenv("TWITTER_API_KEY")  
TWITTER_API_SECRET = os.getenv("TWITTER_API_SECRET")  
TWITTER_ACCESS_TOKEN = os.getenv("TWITTER_ACCESS_TOKEN")  
TWITTER_ACCESS_SECRET = os.getenv("TWITTER_ACCESS_SECRET")  

BOOM_BSC_ADDRESS = "0xcd6A51559254030cA30C2FB2cbdf5c492e8Caf9c"  
DEXSCREENER_API = f"https://api.dexscreener.com/latest/dex/tokens/{BOOM_BSC_ADDRESS}"  
BSC_TX_API = f"https://api.bscscan.com/api?module=account&action=txlist&address={BOOM_BSC_ADDRESS}&apikey={BSC_API_KEY}"  

def get_boom_price():  
    response = requests.get(DEXSCREENER_API)  
    data = response.json()  
    price = data["pairs"][0]["priceUsd"]  
    return f"🚀 Boom Token (BSC) Price: ${price}"  

def post_boom_update():  
    auth = tweepy.OAuthHandler(TWITTER_API_KEY, TWITTER_API_SECRET)  
    auth.set_access_token(TWITTER_ACCESS_TOKEN, TWITTER_ACCESS_SECRET)  
    api = tweepy.API(auth)  
    price = get_boom_price()  
    tweet = f"{price} 🚀 #BoomToken #BSC #DeFi"  
    api.update_status(tweet)  
    print("✅ Tweet posted!")  

if __name__ == "__main__":  
    print(get_boom_price())  
    post_boom_update()  
